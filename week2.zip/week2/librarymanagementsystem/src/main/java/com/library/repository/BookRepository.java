package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

    public void accessData() {
        System.out.println("Repository method called...");
    }
}
