package com.library1.repository;

public class BookRepository {

    public void accessData() {
        System.out.println("Repository method called...");
    }
}